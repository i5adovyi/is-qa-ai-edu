"""Academy regression tests."""
