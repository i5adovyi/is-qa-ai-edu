AI ENGINEERING ACADEMY — PORTABLE EDITION

Extract this entire folder. Python 3.9+ is required for the local server.
Open a terminal in this folder and run: python3 serve.py
On Windows, use: py -3 serve.py
Visit http://127.0.0.1:8765 and keep the terminal open. Stop with Ctrl+C.

No OpenAI account is required for this local portal.
Import your separately exported progress JSON on the Progress page.
Personal progress, credentials and chat history are NOT in this bundle.
External videos/courses require internet; live-model labs need their own access.
Editable sources are in dist/academy-source.zip. The PDF is dist/fieldbook.pdf.
Read ACCOUNT-MIGRATION.md and CONTINUE-LEARNING.md before changing accounts.
