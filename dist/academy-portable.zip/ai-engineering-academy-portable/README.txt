AI ENGINEERING ACADEMY - PORTABLE EDITION

Extract this entire folder. Python 3.9+ is required.
Run: python3 academy.py local
On Windows: py -3 academy.py local
Keep the terminal open. Stop with Ctrl+C.
The browser opens http://127.0.0.1:8765/.
Use --port 8766 for another port, or --no-browser to print the URL only.
The older python3 serve.py command also works.

Open the existing private OpenAI Site: python3 academy.py hosted
No OpenAI account is required for the local portal.
Local progress is saved in .academy-data/progress.sqlite3 between sessions.
Back up: python3 academy.py backup --output /path/to/new-backup.sqlite3
Import your separately exported progress JSON on the Progress page.
Personal progress, credentials and chat history are NOT in this bundle.
External resources need internet; live-model labs need their own access.
Editable sources: dist/academy-source.zip. PDF: dist/fieldbook.pdf.
Read RUN-ANYWHERE.md, ACCOUNT-MIGRATION.md and CONTINUE-LEARNING.md.
